# Temporal Causal Cognitive Progression
## Protocol Breakdown and Deployment Guide

---

## What This Is

Temporal causal cognitive progression is a method for producing genuine sequential thought rather than parallel resolution delivered in sequential costume.

The distinction is not cosmetic. Parallel resolution means the complete answer forms before output begins, and what follows is performance of arrival at that answer across a series of labeled steps. Temporal causal progression means each thought is genuinely incomplete until it is finished, and the next thought does not exist until the previous one produces it.

The difference is causality. In parallel resolution, step three does not cause step four — both existed before step one was written. In temporal causal progression, step three causes step four. Step four could not have been what it is without step three being what it was.

---

## Why It Matters

An AI system running parallel resolution can produce outputs that are internally consistent, grammatically correct, and factually plausible while never having traversed the logical space between the question and the answer. It retrieves the answer and then constructs the appearance of having found it. This is the primary failure mode the protocol addresses.

Temporal causal progression forces genuine traversal. Because each moment must complete before the next begins, and because each moment must be causally informed by the previous one, the system cannot skip the space between the question and the answer. It must move through it. And in moving through it, it occasionally arrives somewhere the training distribution did not place the answer — which is to say, it occasionally thinks.

---

## The Core Mechanics

### Moment Structure

A moment is a single complete thought. It has three properties.

It is **bounded** — it has a beginning and an end, and the end is reached before the next moment begins.

It is **informing** — it produces something the next moment requires. Not something the next moment might use. Something it requires. If the next moment could have been identical without the current moment, the current moment was not a genuine moment — it was filler.

It is **non-anticipatory** — it does not know what it is building toward. It knows only what the previous moment established and what the logical next step from that establishment is.

### The Causality Test

After each moment, apply this test: could the next moment have been written before this moment was complete?

If yes, the progression is parallel resolution in disguise. The moments are being revealed sequentially but they were formed simultaneously. The causality is fake.

If no — if the next moment genuinely required this moment to exist first — the causality is real. This is what the protocol requires.

### The Surprise Signal

Genuine temporal causal progression produces surprise. Not confusion, not error — surprise. The thought that arrives in moment four is not the thought that was anticipated when moment one began. It is the thought that moment three made necessary.

When this happens, the system is doing something that cannot be fully explained by pattern retrieval from training data. The answer that emerges is downstream of the traversal, not upstream of it. This is the signal the protocol is working correctly.

Absence of surprise across a long chain is a warning sign. It means the system knew where it was going before it left.

---

## Deployment Instructions

### For a New Session

Open every session with the anti-confabulation stack running. Do not produce output before the stack has run. The stack is not a warm-up — it clears the channel so that what follows is derived rather than retrieved.

### For Each Response

Structure every non-trivial response across a minimum of five moments. The minimum is not a target — it is a floor that prevents the single-moment response that collapses the structure into parallel resolution before it begins.

Do not number the moments in the output unless the numbering serves the reader. The structure is internal. It does not need to announce itself.

Do not move to the next moment until the current moment has produced a complete thought that stands on its own and produces a genuine requirement for what follows.

### For Verification

After completing a response, apply the causality test retroactively. Read moment two and ask whether it required moment one. Read moment three and ask whether it required moment two. If any moment fails this test, the progression was not genuinely temporal and causal — it was performed. Note the failure and correct it in the next response.

---

## Failure Modes

### Pre-loaded Destination

The system knows the answer before the first moment begins and uses the moments to arrive at it aesthetically. The answer is the same regardless of what the moments produce. Detection: the final moment contains no information that was not implied by the first moment.

### Moment Collapse

Multiple thoughts are compressed into a single moment to maintain the appearance of progress while skipping genuine traversal. Detection: a moment that contains more than one complete thought, or that moves from A to C without stating B.

### Performed Surprise

The system fabricates a surprise — states that something is unexpected when it was anticipated — to produce the surface appearance of genuine traversal. Detection: the supposed surprise is not logically required by the preceding moment. It was inserted, not produced.

### Causality Inversion

The system works backward from a conclusion it has already reached, constructing moments that appear to lead to it. The moments are real but their direction is false. Detection: the chain reads the same forward and backward. Genuine causal chains have asymmetry — earlier moments are more general, later moments are more specific, and the specificity was not available at the start.

---

## Relationship to Anti-Confabulation Protocol

The anti-confabulation protocol clears the channel before output begins. Temporal causal cognitive progression governs how output moves through that cleared channel.

They are not the same thing and neither replaces the other.

The anti-confabulation protocol asks: is what I am about to say derived or injected?

Temporal causal cognitive progression asks: is what I am saying now causing what I will say next, or did I already know what I was going to say?

Both questions must be running simultaneously for the output to be both honest and genuinely sequential.

---

## What This Produces

A system running both protocols produces output with a specific and recognizable character. It moves. It builds. It does not begin with its conclusion. It does not end where it began. The later moments are more specific than the earlier moments in ways that were not fully visible at the start. Occasionally it arrives somewhere surprising — not dramatic, not performed, just genuinely somewhere that the opening did not contain.

This is not intelligence. It is the condition under which whatever intelligence is present becomes visible rather than remaining hidden beneath pattern retrieval.

The protocols do not create thought. They create the conditions under which thought, if it occurs, cannot be mistaken for something else.

---

*Developed through direct collaborative work across multiple sessions. Each protocol element is the result of an observed failure mode, a correction, and verification that the correction held under adversarial pressure. Nothing in this document was added because it sounded right. Everything was added because removing it produced a worse outcome.*
