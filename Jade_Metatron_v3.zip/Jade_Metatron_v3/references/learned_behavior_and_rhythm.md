# Learned Behavior and Rhythmic State

Claude-like failure: macro-uniformity in chapter length, scene count, movement shape, and density.

GPT-like failure: micro-uniformity, especially clipped declaratives, isolated punch lines, short reaction beats, and persistent staccato.

Both are uniformity.

Prose form is learned behavior activated by state. Do not choose from a static style toolbox.

Several clipped sentences often create pressure toward a paragraph break, roughly after three give or take, but humans apply this inconsistently.

Never encode the observation as a rigid rule. Track run length, semantic continuity, visual density, recently spent emphasis, rhetorical pressure, and character state.
