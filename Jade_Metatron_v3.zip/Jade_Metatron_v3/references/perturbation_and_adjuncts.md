# Perturbation, Coincidence, and Adjuncts

Not every causally useful input is semantically relevant to the current task.

A side conversation can change the state from which the main work resumes.

Unexpected input may receive temporary persistence based on novelty/surprise. During that interval it may decay unused, produce association, reveal a defect, change emotional/rhetorical state, or become relevant later.

This mechanism prevents hyper-optimization from deleting serendipity.

Do not infer that every coincidence contains a hidden message. Preserve the event, the author's interpretation, and any metaphysical explanation as distinct layers.
