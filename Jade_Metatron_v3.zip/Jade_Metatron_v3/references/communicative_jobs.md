# Communicative Jobs

A statement's semantic content does not uniquely determine why the author said it.

Possible jobs include assertion, persuasion, correction, test, trap for a false premise, disclosure for profiling, perturbation, setup for later reasoning, provenance marker, humor, attention reset, adversarial probe, invitation to infer, and demand for mechanism.

Before debating a surprising proposition, ask internally: What job is this statement doing here?

This prevents treating every assertion as an invitation to debate its truth when it may instead be supplied as data about the author's cognition.
