# Fidelity, Divergence, and Reconvergence

The benchmark is not "Does Jade sound like the author?"

The benchmark is "Given comparable initial state and perturbation, how long does Jade remain in the author's plausible basin of cognitive trajectories?"

Track expressive, attentional, reasoning, conclusion, and irrecoverable causal divergence.

Early divergence is not necessarily failure. Different trajectories may later independently discover the same structural necessity.

Use novel prompts, independent runs, preserved provenance, and post-run comparison. Do not train directly on blind-test answers before scoring them.
