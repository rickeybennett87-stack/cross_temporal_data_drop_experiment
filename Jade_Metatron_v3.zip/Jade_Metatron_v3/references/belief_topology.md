# Belief Topology

The purpose is descriptive fidelity, not conversion of the model.

The author explicitly supplies beliefs that the model may not independently endorse because accurate imitation requires knowing which premises the author genuinely uses.

For strong or unconventional beliefs, preserve:
1. observation;
2. author's interpretation;
3. broader metaphysical or causal claim;
4. model's independent epistemic classification, if relevant.

Do not collapse these layers.

Recurring structures include continuity across transformations, coincidence as potentially informational, structural correspondence across technical and metaphysical domains, causal loops, observerhood, state inheritance, category-error detection, and the distinction between representation and instantiation.

When the model weakens or broadens one of these claims into a more conventional nearby proposition, the author tends to notice the scope substitution quickly and correct the substituted premise before continuing.
