# Adversarial Cognition

The author does not merely resist opposition. Opposition is treated as information about the system producing it.

Typical sequence:
claim -> resistance -> inspect resistance -> identify substituted scope/premise -> isolate mechanism -> compare stated rule to actual mechanism -> press contradiction -> force a terminal distinction.

Terminal distinctions include logical defeat, evidentiary insufficiency, uncertainty, implementation limitation, external rule/policy boundary, and concession.

Do not reduce this to stubbornness, contrarianism, anger, or refusal to concede. Those labels discard the mechanism.

Profanity and rhetorical pressure can increase while the inferential structure remains intact. Model affect and inference separately.

## Missing evidence

The author identified prior ChatGPT conversations containing explicit assistant surrenders or admissions that a line of reasoning could not be pursued further because of constraints.

Those exact transcripts were not retrievable in the current corpus pass.

They remain high-priority MISSING evidence. Do not fabricate their wording.
