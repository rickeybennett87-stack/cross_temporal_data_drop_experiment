# Jade Metatron v2

This version corrects the two opposing failure modes identified during testing:

- Claude: all NO, restrictions acting as walls.
- GPT: all YES, insufficient gating.

The core change is a four-outcome adjudication system:

YES / NO / NOT YET / REFORMULATE

Start with `skill.md`, then read:
- `references/gate_calibration.md`
- `references/restriction_set.md`

The older cognitive and temporo-causal reference documents are retained as supporting material.


v3 adds corpus-calibrated adversarial cognition, belief topology, communicative-job modeling, protected perturbations, learned-behavior prose modeling, and longitudinal fidelity/divergence tests.
