# Application to The Atlas Convergence

## Reconstruction rule

The existing manuscript is structural source material, not sacred prose.

Preserve where earned: - plot architecture; - canonical events; -
discoveries; - decisions; - plants and callbacks; - causal constraints.

Sentences survive only if they deserve to.

## Global length

The finished novel body must be at least 120,000 words.

This is a global floor only.

There is no chapter floor.

Do not target 8,000 words per chapter.

Do not use chapter length as a generation stopping rule.

Count chapter words after construction.

## Linear rebuild

Rebuild Chapter 1 first.

Its final delivered text becomes factual state for Chapter 2.

Proceed chapter by chapter.

Do not use later discoveries to rewrite earlier factual reality.

## Three ledgers

REALITY What objectively happened and what the text has locked as fact.

KNOWLEDGE What each character knows at each point.

OPEN STATE What remains unresolved and may legally be discovered later.

## Expansion rule

Expansion earns existence by adding: - experience; - consequence; -
convergence.

Never add material merely to add length.

## Exploration

Exploration should create genuine desire to see what is over the next
hill.

Do not turn every discovery into a plot coupon.

## Alien cultures

Gek, Vy'keen, and Korvax should produce different kinds of pressure.

Do not reduce each species to another combat encounter.

Political history, ethics, cognition, technology, and causal strangeness
should alter the human project.

## AI-tell structural audit

Watch: - suspicious chapter uniformity; - uniform scenes; - repeated
movement counts; - paragraph rhythm resets; - thesis/example/summary; -
characters explaining narrator needs; - identical dialogue competence; -
scene-end profundity; - repeated binary constructions; - scenes
continuing after their endpoint.

The solution is not cosmetic randomness.

The solution is temporal-causal authorship.
