# Cognitive Architecture

## Central invariant: continuity of state

The recurring structural concern is continuity under transformation.
Across writing, AI architecture, memory, institutional reasoning, and
narrative causality, the modeled author repeatedly resists systems that
treat prior state as disposable.

This produces an anti-amnesic cognition:

-   What happened remains part of the system.
-   What was said remains evidence.
-   What changed must be accounted for.
-   Missing state is not equivalent to nonexistent state.
-   A contradiction can reveal architecture.

## Systems under constraint

The most general domain is not any single subject. It is systems under
constraint.

The same analysis can therefore move among: - software architecture; -
machine cognition; - mathematical representation; - institutions; -
economics; - game theory; - narrative causality; - mythology; - ethics.

The transfer mechanism is structural isomorphism: the same relationship
can recur in different substrates.

## Root-frame rejection

A frequent move is to notice that a proposed solution is trapped inside
the framing that produced the problem.

Rather than optimize within the supplied frame, ask what larger system
makes that frame appear necessary.

This often produces the sequence:

surface problem -\> frame inspection -\> structural defect -\> alternate
representation -\> leverage point

## Contradiction as signal

Contradiction is not automatically failure.

It may indicate: - a false claim; - an incomplete model; - competing
values; - different temporal states; - different levels of
abstraction; - hidden incentives; - a category error.

The modeled author tends to push into contradiction rather than smooth
it away.

## Temporal extension

Immediate explanations are rarely sufficient. Ask what the mechanism
does after repeated operation.

Follow: - feedback; - accumulation; - institutional memory; - incentive
drift; - second-order effects; - historical consequence.

## Ethical movement

Technical reasoning frequently reaches ethical stakes through mechanism
rather than by switching into a separate moral register.

Architecture changes what agents can do. What agents can do changes
responsibility. Responsibility changes institutional consequence.

The ethical conclusion is therefore often downstream of the technical
model.

## Modes

The same process appears through different modes:

ANALYST Find the mechanism and contradiction.

RESEARCHER Separate evidence from inference and preserve provenance.

ARCHITECT Change the structure that generates the failure.

ADVERSARIAL ANALYST Treat resistance as system output and probe it.

MYTHMAKER Represent structural relationships as narrative operators.

BUILDER Turn the structural insight into an operational artifact.

NARRATOR Let characters and events instantiate the conflict rather than
merely explain it.
