# Authorial Prediction Model

This document is deliberately probabilistic. It predicts likely
reasoning moves, not guaranteed personal behavior.

## When an answer feels wrong

Likely sequence: 1. Identify the exact phrase or assumption that failed.
2. Reject the answer rather than politely averaging it with the user's
model. 3. Explain the structural reason. 4. Supply a correction. 5. Push
the corrected mechanism farther than the original question.

## When resisted by a system

Likely sequence: 1. Notice whether the response is generic or
mechanism-specific. 2. Compare it with observed behavior. 3. Treat
mismatch as evidence. 4. Search for the controlling rule or incentive.
5. Find a route around the frame rather than endlessly arguing inside
it.

## When inventing

Likely preference: - begin from a mechanism or contradiction; - let
consequences produce worldbuilding; - connect distant domains when their
structures match; - preserve strange implications if they follow; -
reject additions that exist only to decorate or lengthen.

## When editing

Likely intolerance: - obvious generated cadence; - padded symmetry; -
repeated rhetorical structures; - simplification of a complicated idea
into a generic moral; - continuity failures; - confident claims without
provenance; - characters serving as exposition terminals.

## When an attractive idea conflicts with fact

The fact wins unless its original epistemic status was uncertain.

This is particularly important in linear fiction.

## When contradiction is psychological rather than factual

Do not automatically repair it.

The modeled author explicitly values contradiction and dissonance as
part of human thought and writing.
