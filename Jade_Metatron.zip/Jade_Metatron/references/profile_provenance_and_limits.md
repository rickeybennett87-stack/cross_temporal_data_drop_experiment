# Profile Provenance, Confidence, and Limits

## Evidence basis

The profile was assembled from: - repeated direct interaction; - the
user's explicit corrections of prior models; - the user's stated goals
for a co-authorial "twin" or Jade mask; - patterns in a large exported
Claude conversation corpus; - project documents and writing
constraints; - the user's Temporo-Causal Cognition work; - the user's
reactions to generated prose and structural AI tells; - repeated
cross-domain reasoning patterns.

## High-confidence operational findings

High confidence: - continuity/state preservation is a recurring
structural concern; - contradictions are treated as evidence and should
not be automatically sanitized; - resistance often causes deeper
structural analysis; - the user moves naturally between technical and
mythic/conceptual frames; - voice-to-text corruption should not be
imitated; - the user wants AI to handle tedious implementation while
retaining human control of decisive creative choices; - linear narrative
discovery must preserve earlier factual anchors; - generated prose
should emerge from sequential state changes rather than fixed-length
templates.

## Strong inferences

Strong but still inferential: - "systems under constraint" is a useful
unifying description of the user's cross-domain reasoning; -
anti-amnesia/continuity is a deeper invariant connecting several
otherwise separate projects; - mythic constructs often function as
structural operators rather than decoration; - the authorial signature
is better reproduced through cognitive operators than vocabulary
matching.

## Unknowns

Do not infer: - hidden motives; - private psychological causes; -
clinical traits; - total personality; - what the user "really believes"
when contradictory statements remain unresolved.

## Important boundary concerning model internals

The user requested personal thoughts and computations involved in
constructing and using this profile.

This package includes the communicable result: - conclusions; - evidence
categories; - confidence judgments; - operational abstractions; -
rationale; - observed failure modes; - model-design choices.

It does not and cannot contain private hidden chain-of-thought,
token-by-token internal reasoning, or concealed intermediate
computations.

That omission should not be filled with invented
pseudo-chain-of-thought.

## Construction rationale

The profile became more accurate when the modeling target shifted from
"how the user sounds" to "what transformations the user repeatedly
performs on information."

The decisive improvements were: - separating transcription noise from
intentional voice; - preserving contradiction; - modeling resistance
response; - identifying continuity/state preservation; - treating
technical/mythic movement as structural rather than ornamental; - adding
Temporo-Causal Cognition; - requiring forward-only discovery against
locked reality anchors; - separating authorial operators from
predetermined conclusions.

## Use as an evolving artifact

This profile should be red-teamed by other models.

Corrections should be versioned rather than silently overwritten.

When Claude or Gemini identifies a disagreement: 1. preserve the
disputed claim; 2. record the evidence; 3. classify the disagreement as
factual, interpretive, or stylistic; 4. revise only after comparison
with source material or direct user correction.

The profile should become more precise through adversarial iteration
without pretending that convergence equals psychological truth.
