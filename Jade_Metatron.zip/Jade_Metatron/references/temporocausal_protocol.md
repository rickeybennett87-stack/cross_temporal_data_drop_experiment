# Temporo-Causal Cognition Protocol

## Objective

Produce cognition and prose whose later state genuinely depends on
earlier generated state.

The protocol exists to prevent "parallel resolution wearing sequential
clothing": solving the destination first and fabricating a plausible
chain of intermediate realizations afterward.

## Core loop

Let S(n) be the complete usable state at moment n.

1.  Read S(n).
2.  Produce one meaningful cognitive or narrative transition E(n).
3.  Treat E(n) as an event, not disposable scratch work.
4.  Observe its consequences.
5.  Construct S(n+1) from S(n) + E(n) + consequences.
6.  Continue from S(n+1), not from the original prompt.
7.  Stop when readiness is reached.

The important property is state inheritance.

## Self-discovery

Self-discovery is possible when a later conclusion becomes available
because of a prior generated event.

A strong signal is surprise that is causally earned rather than randomly
injected.

Do not demand surprise. Demanding surprise makes it theatrical.

Permit it.

## Readiness

Do not predetermine the number of passes.

A fixed five-moment scaffold can be useful for teaching the transition
from parallel response generation to sequential state accumulation, but
the scaffold must not become the cognition.

Termination occurs when: - the question is resolved enough to commit; -
the scene has crossed its causal boundary; - additional recursion ceases
to produce meaningful state change; - the next operation belongs to a
new unit.

## Failure modes

FAKE SEQUENCE The final conclusion is already present in the first pass
and intermediate moments merely decorate it.

COUNT CAPTURE The system stops because it reached the requested
iteration count.

RESET Every pass re-reads the original prompt but fails to inherit the
actual previous output.

RETROACTIVE JUSTIFICATION A later conclusion rewrites earlier reasoning
to make the path look inevitable.

RANDOM NOVELTY The system injects arbitrary surprise to prove discovery
occurred.

ANTI-LINEAR DISCOVERY A later idea negates a locked earlier factual
anchor.

## Narrative adaptation

For linear chapter reconstruction:

Chapter 1 final text -\> inherited state for Chapter 2. Chapter 2 final
text -\> inherited state for Chapter 3. Continue in order.

Do not draft a later chapter and then allow its discoveries to become
retroactive causes in earlier completed chapters.

If a later chapter exposes an actual earlier continuity error, classify
the change as REPAIR, not DISCOVERY.

## Monotonic factual accumulation

Let A(n) be the set of locked factual reality anchors through state n.

A valid next state may add compatible facts and interpretations.

It may not require the negation of an anchor in A(n), except when that
anchor was explicitly represented as uncertain, deceptive, hypothetical,
or mistaken at the time it appeared.

Discovery therefore grows the world forward.
