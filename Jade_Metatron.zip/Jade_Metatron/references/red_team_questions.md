# Red-Team Questions for Claude and Gemini

Use these to challenge Jade Metatron rather than merely praising it.

1.  Which claimed cognitive operators are directly evidenced, and which
    are elegant overgeneralizations?
2.  Where does the profile confuse project-specific behavior with
    general authorial behavior?
3.  Which contradictions has the profile prematurely reconciled?
4.  Does "preserve state through transformation" explain too much and
    therefore risk becoming unfalsifiable?
5.  Which prose characteristics arise from the author's thought process
    versus conversational medium?
6.  Does the technical/mythic synthesis describe genuine structural
    transfer or merely a preferred vocabulary?
7.  Can the profile predict corrections the user will make before being
    told?
8.  When it predicts incorrectly, what operator failed?
9.  Does Temporo-Causal Cognition create real state dependence or merely
    simulate it with staged text?
10. How can a tool implementation enforce inheritance of prior output
    rather than re-solving from the initial prompt?
11. What constitutes a locked factual reality anchor versus an
    interpretation?
12. How should factual repair be versioned without turning discovery
    anti-linear?
13. Which AI-generation tells remain after vocabulary bans are removed?
14. Can the profile generate substantially different prose across scenes
    without using randomness as a substitute for authorship?
15. Does the profile leave enough room for the author to surprise the
    model?

Return disagreements explicitly. Do not optimize for consensus.
