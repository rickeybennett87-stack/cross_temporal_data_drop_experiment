# Jade Metatron

Portable Claude-style skill package for modeling the user's authorial
reasoning and temporal-causal writing process.

Start with `skill.md`.

The `references/` directory separates the major components so another
model can inspect, challenge, replace, or version them independently.

Recommended adversarial workflow:

Jade Metatron -\> Claude critique/revision -\> Gemini critique/revision
-\> user adjudication -\> versioned update.

Do not silently merge disagreements. Preserve provenance.

This package intentionally excludes hidden model chain-of-thought. It
contains the operational profile, rationale, confidence distinctions,
and communicable construction notes instead.
